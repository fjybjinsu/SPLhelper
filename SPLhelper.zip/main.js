﻿'use strict';
// 출력 부분 변수
const spl = document.querySelector('.splInput');
const btnCopy = document.querySelector('.spl_btn');

// 내부 침해 행위 변수
const ddBanCon = document.querySelector('#nac_unit');
const ddPhone = document.querySelector('#phone_unit');
const ddWireless = document.querySelector('#wireless_unit');
const ddBanSW = document.querySelector('#sw_unit');
const btnVirus = document.querySelector('#virus > span > input.submit_btn');

let inputUnit = '';
let inputIP = '';

// 기타 침해 행위 변수
const callServerVul = document.querySelector('#callserver');
const nacMessage = document.querySelector('#nac_message');
const utmUnnormal = document.querySelector('#utm_unnormal');
const gbUnnormal = document.querySelector('#gb_unnormal');
const portScan = document.querySelector('#port_scan');

// 자체 검색 변수
let selfSPL = `index="roka_utm" unit="[마스킹]*" `;
let logtype = `index="roka_utm" unit="[마스킹]*" sourcetype="ahn_*"`;

let srcSPL=logtype;
let dstSPL=srcSPL;
let src_ip_input ='';
let src_port_input='';
let dst_ip_input ='';
let dst_port_input='';
const btnSrcSubmit = document.querySelector('#srcbtn');
const btnDstSubmit = document.querySelector('#dstbtn');


const sourcetype = document.querySelectorAll('[name="sourcetype"');

const src_ip = document.querySelector('#src_ip_input');
const src_port = document.querySelector('#src_port_input');

const dest_ip = document.querySelector('#dest_ip_input');
const dest_port = document.querySelector('#dest_port_input');

let timePre = dstSPL + `| eval time=strftime(_time, "%Y-%m-%d %H:%M")`
let tblSPL= timePre;
let srcip=``;
let srcport=``;
let destip= ``;
let destport=``;


const radioTableResult = document.querySelector('#table_result');
const chkTblSrcIp = document.querySelector('#src_ip_table');
const chkTblSrcPort = document.querySelector('#src_port_table');
const chkTblDstIp = document.querySelector('#dst_ip_table');
const chkTblDstPort = document.querySelector('#dst_port_table');

const radioStatResult = document.querySelector('#stat_result');
const chkStatSrcIpCount = document.querySelector('#src_ip_count');
const chkStatSrcPortCount = document.querySelector('#src_port_count');
const chkStatDstIpCount = document.querySelector('#dst_ip_count');
const chkStatDstPortCount = document.querySelector('#dst_port_count');

const chkStatSrcIpDc = document.querySelector('#src_ip_dc')
const chkStatSrcPortDc = document.querySelector('#src_port_dc')
const chkStatDstIpDc = document.querySelector('#dst_ip_dc')
const chkStatDstPortDc = document.querySelector('#dst_port_dc')

const chkStatSrcIpValues = document.querySelector('#src_ip_values')
const chkStatSrcPortValues = document.querySelector('#src_port_values')
const chkStatDstIpValues = document.querySelector('#dst_ip_values')
const chkStatDstPortValues = document.querySelector('#dst_port_values')

let sort_result = tblSPL
let sort_srcip = ``;
let sort_srcport = ``;
let sort_destip = ``;
let sort_destport = ``;
const chkSortSrcIp = document.querySelector('#src_ip_sort')
const chkSortSrcPort = document.querySelector('#src_port_sort')
const chkSortDstIp = document.querySelector('#dst_ip_sort')
const chkSortDstPort = document.querySelector('#dst_port_sort')

// /내부 침해 행위 검색-----------------------------------------------------------------
function SetInputUnit(ddElement){
	if(ddElement == ddBanCon){
		ddElement.addEventListener('change', (event)=>{
			inputUnit = ddBanCon.value;
			spl.innerText=``;
			spl.innerText=`index=[마스킹] "비관리" sensor_ip="*[마스킹]_${inputUnit}*"
| eval IP=if(isnotnull(IP), IP, node_ip), MAC=if(isnotnull(MAC), MAC, node_mac)
| eval ipSplit=split(IP, "."), ipClassA=mvindex(ipSplit, 0), ipClassB=mvindex(ipSplit, 1), ipClassC=mvindex(ipSplit, 2), ipClassD=mvindex(ipSplit, 3)
| rex field="MAC" "(?<MAC_com>^[A-Z0-9]{1,2}\:[A-Z0-9]{1,2}\:[A-Z0-9]{1,2})"
| lookup MACLIST_ALL.csv MAC_1 as MAC_com OUTPUTNEW COMPANY
| lookup 3corps_MACLIST_supplement.csv MAC_com OUTPUTNEW COMPANY
| search ( (NOT IP IN (169.254.0.0/16, 192.168.0.0/16, 18.0.0.0/8, 72.4.0.0/16))
OR (ipClassA=18 AND (NOT ipClassB IN (34, 35)) AND ipClassC IN (66, 67)) )
AND NOT ([| inputlookup 3corps_UnmanagedNode_exceptions.csv | fields IP, MAC | format] OR (IP=192.0.0.192 AND COMPANY="Hewlett Packard"))
| eval date=strftime(_time, "%F")
| stats max(date) as lastLoggedDate, min(_time) as firstLoggedTime, max(_time) as lastLoggedTime, dc(_time) as numofLog, values(IP) as IP, values(sensor_ip) as sensor_ip, values(FULL_MESSAGE) as FULL_MESSAGE values(COMPANY) as COMPANY by MAC
| sort - lastLoggedTime
| eval lastLoggedTime=strftime(lastLoggedTime, "%F %T")
| eval lastLoggedTime=case(numofLog>1, lastLoggedTime."(등 ".numofLog."회)", 1=1, lastLoggedTime)
| table lastLoggedDate, lastLoggedTime, IP, MAC, sensor_ip, COMPANY
| rename lastLoggedDate as "최종 탐지 일자", lastLoggedTime as "최종 탐지 시간(24h 내 탐지 횟수)", IP as "IP", MAC as "MAC", sensor_ip as "센서"`;
		});
	} else if (ddElement == ddPhone){
		ddElement.addEventListener('change', (event)=>{
			inputUnit = ddPhone.value;
			spl.innerText=``;
			spl.innerText=
`index=[마스킹] sensor_ip=*[마스킹]_${inputUnit}*" ("장치 디바이스 차단됨. ID=비인가장치_무선장치, CLASS=네트워크 어댑터")
| eval IP=if(isnotnull(IP), IP, node_ip), MAC=if(isnotnull(MAC), MAC, node_mac)
| search NOT ID IN("CD-ROM 차단", "CDROM제어", "휴대용 장치")
| eval date=strftime(_time, "%F")
| stats max(date) as lastLoggedDate, max(_time) as lastLoggedTime, dc(_time) as numofLog, values(IP) as IP, values(sensor_ip) as sensor_ip by MAC
| sort - lastLoggedTime
| eval lastLoggedTime=strftime(lastLoggedTime, "%F %T")
| eval lastLoggedTime=case(numofLog>1, lastLoggedTime."(등 ".numofLog."회)", 1=1, lastLoggedTime)
| table lastLoggedDate, lastLoggedTime, detectionType, detectionName, IP, MAC, sensor_ip
| rename lastLoggedDate as "최종 탐지 일자", lastLoggedTime as "최종 탐지 시간(24h 내 탐지 횟수)", IP as "IP", MAC as "MAC", sensor_ip as "센서"`;
		});
	} else if (ddElement == ddWireless){
		ddElement.addEventListener('change', (event)=>{
			inputUnit = ddWireless.value;
			spl.innerText=``;
			spl.innerText=`index=[마스킹] sensor_ip="[마스킹]_${inputUnit}*" ("장치 디바이스 차단됨. ID='1', CLASS='소프트웨어 구성 요소'")
| eval IP=if(isnotnull(IP), IP, node_ip), MAC=if(isnotnull(MAC), MAC, node_mac)
| eval date=strftime(_time, "%F")
| stats max(date) as lastLoggedDate, max(_time) as lastLoggedTime, dc(_time) as numofLog, values(IP) as IP, values(sensor_ip) as sensor_ip by MAC
| sort - lastLoggedTime
| eval lastLoggedTime=strftime(lastLoggedTime, "%F %T")
| eval lastLoggedTime=case(numofLog>1, lastLoggedTime."(등 ".numofLog."회)", 1=1, lastLoggedTime)
| table lastLoggedDate, lastLoggedTime, IP, MAC, sensor_ip
| rename lastLoggedDate as "최종 탐지 일자", lastLoggedTime as "최종 탐지 시간(24h 내 탐지 횟수)", IP as "IP", MAC as "MAC", sensor_ip as "탐지 센서"`;
		});
	} else {
		ddElement.addEventListener('change', (event)=>{
			inputUnit = ddBanSW.value;
			spl.innerText=``;
			spl.innerText=`
index=[마스킹] sensor_ip="[마스킹]_${inputUnit}*" ("장치 디바이스 차단됨. ID='1', CLASS='소프트웨어 구성 요소'")
| eval IP=if(isnotnull(IP), IP, node_ip), MAC=if(isnotnull(MAC), MAC, node_mac)
| eval date=strftime(_time, "%F")
| stats max(date) as lastLoggedDate, max(_time) as lastLoggedTime, dc(_time) as numofLog, values(IP) as IP, values(sensor_ip) as sensor_ip by MAC
| sort - lastLoggedTime
| eval lastLoggedTime=strftime(lastLoggedTime, "%F %T")
| eval lastLoggedTime=case(numofLog>1, lastLoggedTime."(등 ".numofLog."회)", 1=1, lastLoggedTime)
| table lastLoggedDate, lastLoggedTime, IP, MAC, sensor_ip
| rename lastLoggedDate as "최종 탐지 일자", lastLoggedTime as "최종 탐지 시간(24h 내 탐지 횟수)", IP as "IP", MAC as "MAC", sensor_ip as "탐지 센서"`;
		});
	}
}

SetInputUnit(ddBanCon);
SetInputUnit(ddPhone);
SetInputUnit(ddWireless);
SetInputUnit(ddBanSW);


btnVirus.addEventListener('click', (event)=>{
	inputIP = document.querySelector('#virus_input').value;
	if (inputIP == '') inputIP = '*';
	spl.innerText=``;
	spl.innerText=`
	index=[마스킹] sourcetype=[마스킹] host IN ([마스킹]) ip IN (${inputIP})
	| eval isException = case(
		name LIKE "%EICAR%" OR
		name LIKE "%KeyGen%" OR
		name LIKE "%Keygen%" OR
		name LIKE "%X97M%" OR
		name LIKE "%XF/Sic%" OR
		name LIKE "%HackTool%" OR
		name LIKE "%ALS%" OR
		name LIKE "%ACAD%" OR
		name LIKE "%Polip%", "TRUE", 1=1, "false")
	| eval name=if(isException="TRUE", "(예외)".name, name)
	| eval time=strftime(_time, "%F %T"), date=strftime(_time, "%F %T"), client_time=strftime(strptime(client_time, "%Y-%m-%dT%H:%M:%S.%QZ")+60*60*tz_offset, "%F %T")
	| fillnull value="-" file_hash
	| lookup 3corps_epp_code.csv code_id as status OUTPUT code_desc
	| eval desc=client_time." : ".code_desc
	| stats max(date) as lastServerDate, max(time) as lastLoggedTime, values(desc) as logs by ip, name, path, file_hash
	| sort - lastLoggedTime
	| table lastServerDate, ip, name, path, file_hash, logs
	| rename lastServerDate as "최종 탐지 일자", ip as "IP", name as "탐지명", path as "경로", file_hash as "파일 해시값", logs as "로그"`;
});
// /내부 침해 행위 검색(끝)-------------------------------------------------------------


// //기타 침해 행위 검색-----------------------------------------------------------------
// 교환기 서버 취약점
callServerVul.addEventListener('click', (event)=>{
	spl.innerText = `index="roka_utm" dest_ip IN [마스킹] dest_port IN [마스킹] | eval time=strftime(_time, "%T")| table time src_ip src_port dest_ip dest_port`
});

//nac 인스턴스 메시지
nacMessage.addEventListener('click', (event)=>{
	spl.innerText = `index="roka_utm"  src_port IN [마스킹] dest_port IN[마스킹] NOT src_ip IN [마스킹] NOT dest_ip IN[마스킹]| eval time = strftime(_time, "%F %T") | table time src_ip src_port dest_ip dest_port`
});

// 비정상 통신
utmUnnormal.addEventListener('click', (event)=>{
	spl.innerText = `index=[마스킹] sourcetype IN("ahn_allow", "ahn_deny") unit="[마스킹]_*"
NOT dest_port IN [마스킹]
NOT dest_ip IN (0.0.0.0/2, 172.16.0.0/16, 192.168.0.0/16, 72.0.0.0/8, 79.0.0.0/8, 169.254.0.0/16, 239.0.0.0/8, 224.0.0.0/8, 255.255.255.255, 172.168.0.0/16, 172.23.0.0/16, 172.31.0.0/16, 172.35.0.0/16, 172.39.0.0/16, 172.50.0.0/16, 172.53.0.0/16)
NOT protocol=6
| search NOT [| inputlookup AbnormalCommunicationExcept.csv | rename SourceIP as src_ip, DestinationIP as dest_ip, DestinationPort as dest_port | fields src_ip, dest_ip, dest_port]
| lookup [마스킹]_utm.csv IP as host OUTPUT Unit
| where isnotnull(Unit)
| eval flag=case(flag_record!="", flag_record, tcp_flag!="", tcp_flag, 1=1, "-")
| eval time=strftime(_time, "%Y-%m-%d %H:%M"), date=strftime(_time, "%Y-%m-%d"), hostUnit= Unit."(".host.")", risk= case(sourcetype like "%allow%" AND protocol="UDP", "UDP이기 때문에 확인 필요", sourcetype like "%allow%" AND protocol="TCP" AND (flag like "%S sa A%" OR flag like "%3Way OK%"), "통신 됨(우선 차단조치 필요)", 1=1, "통신 안됨")
| stats max(date) as date, count as logCount, min(time) as startTime, max(time) as endTime, values(hostUnit) as hostUnit, values(sourcetype) as sourcetype, values(protocol) as protocol, values(Description) as destPortDescription, values(flag) as flag by src_ip, dest_ip, dest_port, risk
| table date, startTime, endTime, hostUnit, src_ip, dest_ip, dest_port, protocol, sourcetype, flag, logCount, risk, destPortDescription
| rename date as "탐지 일자", startTime as "최초 탐지시간", endTime as "마지막 탐지시간", hostUnit as "부대(UTM IP)", src_ip as "출발지(S)", dest_ip as "목적지(D)", dest_port as "목적지 포트", sourcetype as "로그유형", protocol as "프로토콜", flag as "플래그 값", logCount as "로그 수", risk as "실제 통신여부", destPortDescription as "포트 설명"
| sort - "마지막 탐지시간"`
});

// 비정상 통신(gb)
gbUnnormal.addEventListener('click', (event)=>{
	spl.innerText = `index="roka_utm" sourcetype="ahn_allow" src_ip IN ([마스킹]) src_ip IN ([마스킹])
| where sent_data != 0 AND sent_data != ""
| bin _time span=1m aligntime=@m
| stats sum(sent_data) AS sent_data_sum by _time, src_ip, dest_ip
| table _time, src_ip, dest_ip, sent_data_sum
| eval data_gb_sum=tostring(round(sent_data_sum/1024/1024/1024, 2))." GB"
| where sent_data_sum > 1024*1024*1024
| eval time = strftime(_time, "%F %T") 
| table time, src_ip, dest_ip, data_gb_sum
| rename time as "시간"
| rename scr_ip as "출발지"
| rename dest_ip as "도착지"
| rename data_gb_sum as "전송량(GB)"`
});

// 비정상 통신(port scan)
portScan.addEventListener('click', (event)=>{
	spl.innerText = `index=[마스킹]" unit="[마스킹]*" sourcetype="ahn*"
| eval time = strftime(_time, "%F %T") 
| stats dc(dest_ip) as numDestIp dc(dest_port) as numDestPort by src_ip src_port
| where numDestIp > 50 OR numDestPort > 50
| rename numDestIp as "IP스캔 횟수" numDestPort as "포트 스캔 횟수" src_ip as "공격지 IP" src_port as "공격지 포트" dest_ip as "목표 IP" dest_port as "목표 포트"`
});
// //기타 침해 행위 검색(끝)----------------------------------------------------------------
// /// 자체 검색
sourcetype[0].addEventListener('change', (event)=>{
	logtype = `index="[마스킹]" unit="[마스킹]*" `;
	logtype = selfSPL + `sourcetype="ahn_allow"`;
	spl.innerText = logtype;
})

sourcetype[1].addEventListener('change', (event)=>{
	logtype = `index="[마스킹]" unit="[마스킹]*" `;
	logtype = selfSPL + `sourcetype="ahn_deny"`;
	spl.innerText = logtype;
})

sourcetype[2].addEventListener('change', (event)=>{
	logtype = `index="[마스킹]" unit="[마스킹]*" `;
	logtype = selfSPL + `sourcetype="ahn_*"`;
	spl.innerText = logtype;
})

btnSrcSubmit.addEventListener('click', (evnet)=>{
	src_ip_input = document.querySelector('#src_ip_input').value;
	src_port_input = document.querySelector('#src_port_input').value;
	if (src_ip_input == '') src_ip_input = '*';
	if (src_port_input == '') src_port_input = '*';
	srcSPL = logtype + ` src_ip IN (${src_ip_input}) src_port IN (${src_port_input})`
	spl.innerText=srcSPL
});

btnDstSubmit.addEventListener('click', (event)=>{
	dst_ip_input = document.querySelector('#dest_ip_input').value;
	dst_port_input = document.querySelector('#dest_port_input').value;
	if (dst_ip_input == '') dst_ip_input = '*';
	if (dst_port_input =='') dst_port_input ='*';
	dstSPL = srcSPL + ` dest_ip IN (${dst_ip_input}) dest_port IN (${dst_port_input})`
	spl.innerText= dstSPL 
});

radioTableResult.addEventListener('click', (event)=>{
	document.querySelector('#stats_checkbox').style.visibility = "hidden";
	document.querySelector('#table_checkbox').style.visibility = "visible";
	chkTblSrcIp.addEventListener('click', (event)=>{
		if (chkTblSrcIp.checked == true) {
			srcip = `src_ip`
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
		else {
			srcip = ``
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
	});
	chkTblSrcPort.addEventListener('click', (event) =>{
		if (chkTblSrcPort.checked == true){
			srcport = `src_port`
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
		else {
			srcport = ``
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
	});
	chkTblDstIp.addEventListener('click', (event)=>{
		if (chkTblDstIp.checked == true){
			destip = `dest_ip`
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
		else {
			destip = ``
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
	});
	chkTblDstPort.addEventListener('click', (event)=>{
		if (chkTblDstPort.checked == true){
			destport = `dest_port`
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
		else {
			destport = ``
			tblSPL = dstSPL + `| table time ${srcip} ${srcport} ${destip} ${destport}`
			spl.innerText = tblSPL
		}
	});
});

radioStatResult.addEventListener('click', (event)=>{
	document.querySelector('#table_checkbox').style.visibility = "hidden";
	document.querySelector('#stats_checkbox').style.visibility = "visible";

	let cnt_srcip =``
    let cnt_srcport =``
	let cnt_destip=``
	let cnt_destport =``;
	let dc_srcip =``
	let dc_srcport=``
	let dc_destip=``
	let dc_destport =``;
	let val_srcip=``
	let val_srcport=``
	let val_destip=``
	let val_destport =``;

	chkStatSrcIpCount.addEventListener('click', (event)=>{
		
		if (chkStatSrcIpCount.checked == true) {
			cnt_srcip = `count(src_ip) AS "출발지 IP(수)"`
		}
		else {
			cnt_srcip=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatSrcPortCount.addEventListener('click', (event)=>{
		if (chkStatSrcPortCount.checked == true) {
			cnt_srcport =  `count(src_port) AS "출발지 포트(수)"`
		}
		else {
			cnt_srcport=``
		}
		tblSPL =dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatDstIpCount.addEventListener('click', (event)=>{
		if (chkStatDstIpCount.checked == true) {
			cnt_destip = `count(dest_ip) AS "도착지IP(수)"`
		}
		else {
			cnt_destip=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatDstPortCount.addEventListener('click', (event)=>{
		if (chkStatDstPortCount.checked == true) {
			cnt_destport =  `count(dest_port) AS "도착지 포트(수)"`
		}
		else {
			cnt_destport=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	
	chkStatSrcIpDc.addEventListener('click', (event)=>{
		if (chkStatSrcIpDc.checked == true) {
			dc_srcip = `dc(src_ip) AS "출발지 IP(수)"`
		}
		else {
			dc_srcip=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatSrcPortDc.addEventListener('click', (event)=>{
		if (chkStatSrcPortDc.checked == true) {
			dc_srcport = `dc(src_port) AS "출발지 포트(수)"`
		}
		else {
			dc_srcport=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatDstIpDc.addEventListener('click', (event)=>{
		if (chkStatDstIpDc.checked == true) {
			dc_destip = `dc(dest_ip) AS "도착지IP(수)"`
		}
		else {
			dc_destip=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatDstPortDc.addEventListener('click', (event)=>{
		if (chkStatDstPortDc.checked == true) {
			dc_destport = `dc(dest_port) AS "도착지 포트(수)"`
		}
		else {
			dc_destport=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	
	chkStatSrcIpValues.addEventListener('click', (event)=>{
		if (chkStatSrcIpValues.checked == true) {
			val_srcip = `values(src_ip) AS "출발지 IP(중복제거)"`
		}
		else {
			val_srcip=``
		}
		tblSPL = timePre + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
	chkStatSrcPortValues.addEventListener('click', (event)=>{
		if (chkStatSrcPortValues.checked == true) {
			val_srcport = `values(src_port) AS "출발지 포트(수)"`
		}
		else {
			val_srcport=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
			spl.innerText = tblSPL
	});
	chkStatDstIpValues.addEventListener('click', (event)=>{
		if (chkStatDstIpValues.checked == true) {
			val_destip = `values(dest_ip) AS "도착지IP(수)"`
		}
		else {
			val_destip=``
		}
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
		
	});
	chkStatDstPortValues.addEventListener('click', (event)=>{
		if (chkStatDstPortValues.checked == true) {
			val_destport = `values(dest_port) AS "도착지 포트(수)"`
		}
		else {
			val_destport=``
		} 
		tblSPL = dstSPL + `| stats ${cnt_srcip} ${dc_srcip} ${val_srcip} ${cnt_srcport} ${dc_srcport} ${val_srcport} ${cnt_destip} ${dc_destip} ${val_destip} ${cnt_destport} ${dc_destport} ${val_destport}`
		spl.innerText = tblSPL
	});
});


// ///자체 검색(끝)--------------------------------------------------------------------------
// //// 복사 버튼
btnCopy.addEventListener('click', (event)=>{
	spl.select();
	document.execCommand('copy');
	alert("SPL이 클립보드에 복사되었습니다. Search APP에 붙여넣고 시간 범위를 변경한 후 검색해주세요");
});

chkSortSrcIp.addEventListener('click',(event)=>{
	if(chkSortSrcIp.checked == true){
		sort_srcip = `src_ip as "출발지 IP" `
	} else {
		sort_srcip = ``
	}
	sort_result = tblSPL + ` by ${sort_srcip} ${sort_srcport} ${sort_destip} ${sort_destport}`
	spl.innerText = sort_result
});

chkSortSrcPort.addEventListener('click',(event)=>{
	if(chkSortSrcPort.checked == true){
		sort_srcport = `src_port as "출발지 포트" `
	} else {
		sort_srcport = ``
	}
	sort_result = tblSPL + ` by ${sort_srcip} ${sort_srcport} ${sort_destip} ${sort_destport}`
	spl.innerText = sort_result
});

chkSortDstIp.addEventListener('click',(event)=>{
	if(chkSortDstIp.checked == true){
		sort_destip = `dest_ip as "도착지 IP" `
	} else {
		sort_destip = ``
	}
	sort_result = tblSPL + ` by ${sort_srcip} ${sort_srcport} ${sort_destip} ${sort_destport}`
	spl.innerText = sort_result
});

chkSortDstPort.addEventListener('click',(event)=>{
	if(chkSortDstPort.checked == true){
		sort_destport = `dest_port as "도착지 포트" `
	} else {
		sort_destport = ``
	}
	sort_result = tblSPL + ` by ${sort_srcip} ${sort_srcport} ${sort_destip} ${sort_destport}`
	spl.innerText = sort_result
});
// //// 복사 버튼(끝)